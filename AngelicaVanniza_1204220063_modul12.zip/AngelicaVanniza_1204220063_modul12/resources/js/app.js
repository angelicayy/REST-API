import "./bootstrap";
import.meta.glob(["../images/galaxy.jpg"]);

import './bootstrap';
import 'datatables.net-bs5';
import 'datatables.net-buttons-bs5';
import.meta.glob(["../images/**"]);

import './bootstrap';
import 'datatables.net-bs5';
import 'datatables.net-buttons-bs5';
import './employee';
import.meta.glob(["../images/**"]);
